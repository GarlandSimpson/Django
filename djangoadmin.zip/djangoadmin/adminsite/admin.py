from django.contrib import admin
from .models import Course, Instructor, Lesson


class LessonInline(admin.StackedInline):
    """Creates inline Lesson class to work with Course """
    model = Lesson
    extra = 5


class CourseAdmin(admin.ModelAdmin):
    """Creates a Course admin"""
    fields = ['pub_date', 'name', 'description']
    inlines = [LessonInline]


class InstructorAdmin(admin.ModelAdmin):
    """Creates an Instructor admin"""
    fields = ['user', 'full_time']


admin.site.register(Instructor, InstructorAdmin)
admin.site.register(Course, CourseAdmin)
