from django.apps import AppConfig


class AdminsiteConfig(AppConfig):
    name = 'adminsite'
